# Spelling-Correction-using-TextBlob
A simple python program which uses file handling to read text from file, correct the misspelled words and write back to the file
* Since textblob might correct the words which are irrelevant in your text file, it's important to find the candidate words. 
* For all misspelled words,the correct word and other candidate words are recommended
### Requirements: Textblob, pyspellchecker, re(regular expression)
